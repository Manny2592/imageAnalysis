import numpy as np
import pandas as pd
import cv2
import ffmpeg
import os
import pytesseract
from moviepy.editor import VideoFileClip
#import matplotlib
import natsort
import subprocess

os.chdir("D:/Abhishek/Project/STT/Raw Videos/Viz One/English/English/output1")
def find_max(args):
    # returns a list that contains titles of movies having maximum runtime and maximum frames
    find_max_list = []
    for i in args:
        find_max_list.append(i)
    clips = []
    for i in find_max_list:
        clips.append(VideoFileClip(i))
    d = []
    for i in args:
        d.append(str(i))
    duration = []
    for i in clips:
        duration.append(int(i.duration))
    frames = []
    for i in clips:
        frames.append(int(i.reader.nframes))
    max_movies = []
    maxima_frames = int(max(frames))
    maxima_duration = int(max(duration))
    for i in zip(d, duration, frames):
        if (i[1] == maxima_duration) and (i[2]==maxima_frames):
            max_movies.append(i[0])
    return max_movies
    #max_movies is the list that has maximum runtime and maximum frames.

def get_frame_types(video_fn):
    command = 'ffprobe -v error -show_entries frame=pict_type -of default=noprint_wrappers=1'.split()
    out = subprocess.check_output(command + [video_fn]).decode()
    frame_types = out.replace('pict_type=','').split()
    return zip(range(len(frame_types)), frame_types)

def save_i_keyframes(video_fn,prefix):
    basename=prefix
    frame_types = get_frame_types(video_fn)# passing file to the above function
    i_frames = [x[0] for x in frame_types if x[1]=='I']
    if i_frames:
        cap = cv2.VideoCapture(video_fn)
        for frame_no in i_frames:
            cap.set(cv2.CAP_PROP_POS_FRAMES, frame_no)
            ret, frame = cap.read()
            outname = basename+'_i_frame_'+str(frame_no)+'.jpg'
            cv2.imwrite(outname, frame)
            print ('Saved: '+outname)
        cap.release()
    else:
        print ('No I-frames in '+video_fn)

def compare_short_movies(longest_movie, not_the_longest_movies,output):
    dir2 = "D:/Abhishek/Project/STT/Raw Videos/Viz One/English/English/output1/{file}"
    dir1 = r"D:\Abhishek\Project\STT\Raw Videos\Viz One\English\English\output1"
    ##1st condition  all movies have same frame count and same duration
    if len(not_the_longest_movies) == 0:
        #dir2 = "C:/Users/e_man/PycharmProjects/pythonProject1/output1/{file}"
        print("All the movies entered have the same duration and frame count")
        # even though the movies have same duration and frame count it is imperative to check for picture pixel
        #matrices and audio.
        #cmd = []
        #for i in zip(longest_movie, output):
        #    cmd.append(f'ffmpeg -i "{i[0]}" -r 1/120 "{i[1]}"')
        #for i in cmd:
        #    os.system(i)
        #created frames for all the elements in the longest_movie_list.
        for i in zip(longest_movie,output):
            save_i_keyframes(i[0],i[1])

        firstmovie_frames = []
        secondmovie_frames = []
        thirdmovie_frames=[]
        #dir1 = r"C:\Users\e_man\PycharmProjects\pythonProject1\output1"


        for filename in os.listdir(dir1):
            if filename.startswith("abc"):
                firstmovie_frames.append(filename)
        #
        for filename in os.listdir(dir1):
            if filename.startswith("bac"):
                secondmovie_frames.append(filename)

        for filename in os.listdir(dir1):
            if filename.startswith("cab"):
                thirdmovie_frames.append(filename)

        #setup has been provided if three movies that have been enterred all have the same length and framecount.
        #Once the frames have been extracted , it is necessary to perform a sort, so identical frames can be compared with each other.
        sorted_a = natsort.natsorted(firstmovie_frames, reverse=False)
        sorted_b = natsort.natsorted(secondmovie_frames, reverse=False)
        sorted_c = natsort.natsorted(thirdmovie_frames,reverse=False)
        image_amovie = []
        image_bmovie = []
        image_cmovie = []

        for i in sorted_a:
            image_amovie.append(cv2.imread(dir2.format(file=i)))

        for i in sorted_b:
            image_bmovie.append(cv2.imread(dir2.format(file=i)))
        print(sorted_b)
        for i in sorted_c:
            image_cmovie.append(cv2.imread(dir2.format(file=i)))
        print(sorted_c)
        frame_counter = 0
        #Now comparision of the three lists having the matrices of the selected frames are to be compared to
        #and see if the all movies in the longest_movies list are the same.
        for i, j, k in zip(image_amovie, image_bmovie,image_cmovie):
            try:
                difference_1st_two = cv2.subtract(i, j)
                result_1 = not (np.any(difference_1st_two))
                difference_last_two = cv2.subtract(j, k)
                result_2 = not (np.any(difference_last_two))
                difference_first_third = cv2.subtract(i, k)
                result_3 = not (np.any(difference_first_third))
                #duration and number of frames has already been checked
                if (result_1 is True) and (result_2 is True) and (result_3 is True):#difference component
                    if (str(longest_movie[0])==str(longest_movie[1])==str(longest_movie[2])):#title component
                        frame_counter=frame_counter+1
                        # can add audio component as well. # frame counter is added because
                        # frames extracted for each movie should be the same
                        #filecountpermovie == number of frames as all frames should be equal

                elif (result_1 is False) and (result_2 is False) and (result_3 is False):
                    print("Frame mismatch for all movies")

                elif (result_1 is False) and (result_2 is False) and (result_3 is True):
                    if (str(longest_movie[1]) == str(longest_movie[3])):
                        print("Movies are unequal")#can add audio check

                elif (result_1 is False) and (result_2 is True) and (result_3 is False):
                    if (str(longest_movie[2]) == str(longest_movie[3])):
                        print("Movies are unequal")#Can add audio check
                elif (result_1 is True) and (result_2 is False) and (result_3 is False):
                    if (str(longest_movie[1]) == str(longest_movie[2])):
                        print("Movies are unequal")#Can add audio check.

            except:
                print("frames are all unequal")

        path, dirs, files = next(os.walk(dir1))

        file_count_per_movie = int(len(files) / len(longest_movie))
        print(len(longest_movie))
        print(frame_counter)
        print(file_count_per_movie)

        if file_count_per_movie == frame_counter:
            print("Movies are all equal")
        else:
            print("Movies are all unequal")

    #2nd condition: the longest movie is isolated and a thourough check is done on the other two movies to see if
    #they are similar.
    elif (len(not_the_longest_movies)!=0) and (len(not_the_longest_movies)!=1):
        #cmd = []
        #dir2 = "C:/Users/e_man/PycharmProjects/pythonProject1/output1/{file}"
        for i in zip(not_the_longest_movies, output):
            save_i_keyframes(i[0], i[1])
            #cmd.append(f'ffmpeg -i "{i[0]}" -r 1/120 "{i[1]}"')

        # Returns list that
        #   not_the_longest_movies = set(d).difference(longest_movie)
        #   not_the_longest_movies = list(not_the_longest_movies)
        #   print(not_the_longest_movies)
        #   print(d)x
        # cmd2 = f'ffmpeg -i "{name3}" -r 1/120 "{output3}"'

        #for i in cmd:
        #    os.system(i)
        # os.system(cmd2)
        firstmovie_frames = []
        secondmovie_frames = []
        # c=[]
        #dir1 = r"C:\Users\e_man\PycharmProjects\pythonProject1\output1"

        for filename in os.listdir(dir1):
            if filename.startswith("abc"):
                firstmovie_frames.append(filename)
        #
        for filename in os.listdir(dir1):
            if filename.startswith("bac"):
                secondmovie_frames.append(filename)

        #   for filename in os.listdir(dir3):
        #      if filename.startswith("cab"):
        #         c.append(filename)

        sorted_a = natsort.natsorted(firstmovie_frames, reverse=False)
        sorted_b = natsort.natsorted(secondmovie_frames, reverse=False)
        print(sorted_b)
        # sorted_c=natsort.natsorted(c,reverse=False)
        image_amovie = []
        image_bmovie = []
        # image_cmovie=[]

        for i in sorted_a:
            image_amovie.append(cv2.imread(dir2.format(file=i)))

        for i in sorted_b:
            image_bmovie.append(cv2.imread(dir2.format(file=i)))

        frame_counter = 0
        #  for i in sorted_c:
        #      image_cmovie.append(cv2.imread(i))
        for i, j in zip(image_amovie, image_bmovie):
            try:
                difference = cv2.subtract(i, j)
                result = not (np.any(difference))

                if result is True:
                    frame_counter += 1
                else:
                    print("Frames are unequal")

            except:
                print("frames are unequal")

        path, dirs, files = next(os.walk(dir1))

        file_count = int(len(files) / len(not_the_longest_movies))
        print(frame_counter)
        print(file_count)
        if file_count == frame_counter:
            if str(not_the_longest_movies[0]) == str(not_the_longest_movies[1]):
                #checking to see the title name
                clip = VideoFileClip(not_the_longest_movies[0])
                clip1 = VideoFileClip(not_the_longest_movies[1])
                if (int(clip.duration) == int(clip1.duration)):#checking duration again
                    ##can add audio component
                    c=""
                    first_movie = str.split(not_the_longest_movies[0], sep="\\")
                    for i in first_movie:
                        for j in all_movies:
                            if i == j:
                                c = i
                    print(c + "has been found to be entered twice. Both the copies of this movie are same.")
                else:
                    print("Movies are unequal")

        else:
            print("Movies are all unequal_checking ")
    #third condition: there
    elif len(not_the_longest_movies)==1:
        #dir2 = "C:/Users/e_man/PycharmProjects/pythonProject1/output1/{file}"
        for i in zip(longest_movie, output):
            save_i_keyframes(i[0], i[1])
        firstmovie_frames = []
        secondmovie_frames = []
        # c=[]
        #dir1 = r"C:\Users\e_man\PycharmProjects\pythonProject1\output1"

        for filename in os.listdir(dir1):
            if filename.startswith("abc"):
                firstmovie_frames.append(filename)
        #
        for filename in os.listdir(dir1):
            if filename.startswith("bac"):
                secondmovie_frames.append(filename)

        #   for filename in os.listdir(dir3):
        #      if filename.startswith("cab"):
        #         c.append(filename)

        sorted_a = natsort.natsorted(firstmovie_frames, reverse=False)
        sorted_b = natsort.natsorted(secondmovie_frames, reverse=False)
        # sorted_c=natsort.natsorted(c,reverse=False)
        image_amovie = []
        image_bmovie = []
        # image_cmovie=[]

        for i in sorted_a:
            image_amovie.append(cv2.imread(dir2.format(file=i)))

        for i in sorted_b:
            image_bmovie.append(cv2.imread(dir2.format(file=i)))

        print(type(image_amovie[1]))
        frame_counter = 0
        #  for i in sorted_c:
        #      image_cmovie.append(cv2.imread(i))
        for i, j in zip(image_amovie, image_bmovie):
            try:
                difference = cv2.subtract(i, j)
                result = not (np.any(difference))

                if result is True:
                    frame_counter += 1
                else:
                    print("Frames are unequal")

            except:
                print("frames are unequal")

        path, dirs, files = next(os.walk(r"D:\Abhishek\Project\STT\Raw Videos\Viz One\English\English\output1"))

        file_count = int(len(files) / len(longest_movie))
        print(frame_counter)
        print(file_count)
        if file_count == frame_counter:
            if str(longest_movie[0]) == str(longest_movie[1]):
                # checking to see the title name
                clip = VideoFileClip(longest_movie[0])
                clip1 = VideoFileClip(longest_movie[1])
                c = ""
                if (int(clip.duration) == int(clip1.duration)):  # checking duration again
                    ##can add audio component
                    first_movie = str.split(longest_movie[0], sep="\\")
                    for i in first_movie:
                        for j in all_movies:
                            if i == j:
                                c = i
                    print( c + " has been found to be entered twice. Both the copies of this movie are same.")
                else:
                    print("All movies entered are unequal")

        else:
            print("All movies entered are all unequal ")

def compare(args):
    #compares the movies.
    name=[]
    for i in args:
        name.append(i)
    #name is a list that contains the title as strings

    longest_movie = find_max(args)
    # find the longest movie by invoking function.
    not_the_longest_movies = []
    for i in args:
        not_the_longest_movies.append(str(i))
    for i in not_the_longest_movies:
        for j in longest_movie:
            if i == j:
                not_the_longest_movies.remove(i)
    print(not_the_longest_movies)
    # find the movies that are not the longest in terms of frame count and duration.


    output1="abc"
    output2="bac"
    output3="cab"

    try:
        output=[output1,output2,output3]
        compare_short_movies(longest_movie, not_the_longest_movies, output)
    except:
        output=[output1,output2]
        compare_short_movies(longest_movie,not_the_longest_movies,output)

    #output is a directory where the ffmpeg output frames will be stored for the corresponding movies.
    # All the frames of the corresponding movies are placed in the same directory with different prefixes.
    #Encoded values of ouputs  problem cause i have to dynamically allocate the outputs



# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    source_directory=r"D:\Abhishek\Project\STT\Raw Videos\Viz One\English\English\{file_input}"
    print("Enter first movie")
    a=str(input())
    print("Enter second movie")
    b=str(input())
    print("Enter third movie")
    c=str(input())
    all_movies=[a,b,c]
    input1 = source_directory.format(file_input=a)
    input2 = source_directory.format(file_input=b)
    input3= source_directory.format(file_input=c)
    print(os.getcwd())
    compare([input1,input2,input3])
